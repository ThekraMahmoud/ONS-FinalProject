package org.example.ons.Controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class FrontendController {

    @GetMapping({
            "/",
            "/login",
            "/register",
            "/payment",
            "/set-password",
            "/dashboard",
            "/campaign-dashboard",
            "/supervisor-dashboard",
            "/representative-dashboard",
            "/pilgrim-kiosk",
            "/pilgrim-kiosk/setup"
    })
    public String frontend() {
        return "forward:/index.html";
    }
}
