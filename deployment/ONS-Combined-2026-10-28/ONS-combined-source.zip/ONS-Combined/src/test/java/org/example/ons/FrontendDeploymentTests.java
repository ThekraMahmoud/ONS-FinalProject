package org.example.ons;

import org.example.ons.Config.Configuration;
import org.example.ons.Controller.AuthController;
import org.example.ons.Controller.FrontendController;
import org.example.ons.Service.AuthService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.webmvc.test.autoconfigure.WebMvcTest;
import org.springframework.context.annotation.Import;
import org.springframework.core.io.ClassPathResource;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;

import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.regex.Pattern;

import static org.hamcrest.Matchers.containsString;
import static org.mockito.Mockito.when;
import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.httpBasic;
import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.user;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(controllers = {FrontendController.class, AuthController.class})
@Import(Configuration.class)
class FrontendDeploymentTests {

    @Autowired
    private MockMvc mvc;

    @MockitoBean
    private AuthService authService;

    @MockitoBean
    private UserDetailsService userDetailsService;

    @BeforeEach
    void configureAuthentication() {
        when(userDetailsService.loadUserByUsername("deployment-test@example.invalid"))
                .thenReturn(org.springframework.security.core.userdetails.User
                        .withUsername("deployment-test@example.invalid")
                        .password(new org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder(4)
                                .encode("test-only-password"))
                        .authorities("ADMIN")
                        .build());
        when(authService.getAllUsers()).thenReturn(List.of());
    }

    @Test
    void pageRefreshesAndPaymentCallbacksLoadTheReactShellWithoutLogin() throws Exception {
        for (String page : List.of("/", "/login", "/register", "/payment",
                "/set-password", "/dashboard", "/campaign-dashboard",
                "/supervisor-dashboard", "/representative-dashboard",
                "/pilgrim-kiosk", "/pilgrim-kiosk/setup")) {
            mvc.perform(get(page).queryParam("id", "test-callback").queryParam("status", "paid"))
                    .andExpect(status().isOk())
                    .andExpect(forwardedUrl("/index.html"));
        }
    }

    @Test
    void indexAndEveryReferencedScriptAndStylesheetArePublic() throws Exception {
        String html = new ClassPathResource("static/index.html")
                .getContentAsString(StandardCharsets.UTF_8);
        mvc.perform(get("/index.html"))
                .andExpect(status().isOk())
                .andExpect(content().string(containsString("id=\"root\"")));
        var matcher = Pattern.compile("(?:src|href)=\"(/[^\"]+)\"").matcher(html);
        int assets = 0;
        while (matcher.find()) {
            mvc.perform(get(matcher.group(1)))
                    .andExpect(status().isOk());
            assets++;
        }
        org.junit.jupiter.api.Assertions.assertTrue(assets >= 2);
    }

    @Test
    void publicUiDoesNotExposeProtectedApiOrAcceptPageWrites() throws Exception {
        for (String api : List.of("/api/v1/auth/get/all", "/api/v1/campaigns/get",
                "/api/v1/dashboard/summary", "/notification/get", "/report/get")) {
            mvc.perform(get(api).header("X-Requested-With", "XMLHttpRequest"))
                    .andExpect(status().isUnauthorized())
                    .andExpect(header().doesNotExist("WWW-Authenticate"));
        }
        mvc.perform(post("/login"))
                .andExpect(status().isUnauthorized());
    }

    @Test
    void basicAuthenticationStillAllowsAdminToReadTheApi() throws Exception {
        mvc.perform(get("/api/v1/auth/get/all")
                        .with(httpBasic("deployment-test@example.invalid", "test-only-password"))
                        .header("X-Requested-With", "XMLHttpRequest"))
                .andExpect(status().isOk())
                .andExpect(content().json("[]"));
    }

    @Test
    void invalidPasswordStillReturns401WithoutBrowserLoginDialog() throws Exception {
        mvc.perform(get("/api/v1/auth/get/all")
                        .with(httpBasic("deployment-test@example.invalid", "incorrect"))
                        .header("X-Requested-With", "XMLHttpRequest"))
                .andExpect(status().isUnauthorized())
                .andExpect(header().doesNotExist("WWW-Authenticate"));
    }

    @Test
    void otherRolesStillCannotReadTheAdminApi() throws Exception {
        for (String role : List.of("CAMPAIGN_OWNER", "AuthorizedStaff", "FIELDـSTAFF")) {
            mvc.perform(get("/api/v1/auth/get/all").with(user("fixture").authorities(
                            new org.springframework.security.core.authority.SimpleGrantedAuthority(role))))
                    .andExpect(status().isForbidden());
        }
    }

    @Test
    void missingApiAndMissingAssetNeverBecomeHtmlSuccessResponses() throws Exception {
        mvc.perform(get("/api/not-a-real-endpoint").with(user("fixture").roles("ADMIN")))
                .andExpect(status().isNotFound())
                .andExpect(result -> org.junit.jupiter.api.Assertions.assertNull(
                        result.getResponse().getForwardedUrl()));
        mvc.perform(get("/assets/missing-deployment-asset.js"))
                .andExpect(status().isNotFound());
    }
}
