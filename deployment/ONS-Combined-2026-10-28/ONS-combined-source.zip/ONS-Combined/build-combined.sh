#!/usr/bin/env bash
set -euo pipefail

cd "$(dirname "$0")"

if [[ -z "${JAVA_HOME:-}" && -x /usr/libexec/java_home ]]; then
    export JAVA_HOME="$(/usr/libexec/java_home -v 21)"
fi

(
    cd frontend
    pnpm install --frozen-lockfile --ignore-scripts
    node --test tests/calendar.test.mjs tests/qr-flow.test.mjs tests/workspace-contracts.test.mjs
    pnpm run build
)

mkdir -p src/main/resources/static
cp -R frontend/dist/. src/main/resources/static/
bash ./mvnw -Dtest=FrontendDeploymentTests package
